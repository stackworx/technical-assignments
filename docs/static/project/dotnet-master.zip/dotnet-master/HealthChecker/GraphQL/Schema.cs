﻿using System;
using System.Collections.Generic;
using GraphQL;
using GraphQL.Types;

namespace HealthChecker.GraphQL
{

    public class Server
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string HealthCheckUri { get; set; }
        public string Status { get; set; }
    }

    public class ServerType : ObjectGraphType<Server>
    {
        public ServerType()
        {
            Name = "Server";
            Description = "A server to monitor";

            Field(h => h.Id);
            Field(h => h.Name);
            Field(h => h.HealthCheckUri);
            Field(h => h.Status);

        }
    }

    public class HealthCheckerQuery : ObjectGraphType<object>
    {
        public HealthCheckerQuery()
        {
            Name = "Query";


            Func<ResolveFieldContext, string, object> serverResolver = (context, id) => new List<Server>();

            FieldDelegate< ListGraphType<ServerType>>(
                "servers",
                arguments: new QueryArguments(
                    new QueryArgument<StringGraphType> { Name = "id", Description = "id of server" }
                ),
                resolve: serverResolver
            );

            Field<StringGraphType>(
                "hello",
                resolve: context => "world"
            );
        }
    }

    public class HealthCheckerSchema : Schema
    {
        public HealthCheckerSchema(IServiceProvider provider) : base(provider)
        {
            Query = new HealthCheckerQuery();
        }
    }
}
